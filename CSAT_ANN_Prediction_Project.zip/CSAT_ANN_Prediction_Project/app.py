import streamlit as st
import numpy as np
from tensorflow.keras.models import load_model

# Load model without compilation (important fix)
model = load_model("ann_csat_model.h5", compile=False)

st.set_page_config(page_title="CSAT Prediction App", layout="centered")

st.title("📊 Customer Satisfaction (CSAT) Prediction")
st.write("ANN-based CSAT score prediction for e-commerce customer support")

st.markdown("---")

# User inputs (important numerical features)
item_price = st.number_input("Item Price", min_value=0.0)
handling_time = st.number_input("Connected Handling Time", min_value=0.0)
resolution_time = st.number_input("Resolution Time (minutes)", min_value=0.0)
order_issue_delay = st.number_input("Order to Issue Delay (minutes)", min_value=0.0)
issue_hour = st.slider("Issue Reported Hour (0–23)", 0, 23, 12)
issue_day = st.slider("Issue Day of Week (0=Mon, 6=Sun)", 0, 6, 2)

st.markdown("---")

if st.button("🔮 Predict CSAT Score"):

    # Create full input array with 14 features
    full_input = np.zeros((1, 14))

    # Assign values based on training feature order
    full_input[0, 6] = item_price                 # Item_price
    full_input[0, 7] = handling_time              # connected_handling_time
    full_input[0,10] = resolution_time            # resolution_time
    full_input[0,11] = order_issue_delay           # order_issue_delay
    full_input[0,12] = issue_hour                  # issue_hour
    full_input[0,13] = issue_day                   # issue_day_of_week

    prediction = model.predict(full_input)

    predicted_csat = prediction[0][0]

    st.success(f"⭐ Predicted CSAT Score: **{predicted_csat:.2f}**")

    if predicted_csat < 3:
        st.warning("⚠️ Low satisfaction – Immediate action recommended")
    else:
        st.info("✅ Customer satisfaction level is acceptable")

st.caption("CSAT Prediction using ANN | Deep Learning Certificate Project")
